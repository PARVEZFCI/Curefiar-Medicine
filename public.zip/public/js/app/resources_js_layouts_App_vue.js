"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_layouts_App_vue"],{

/***/ "./resources/js/layouts/App.vue":
/*!**************************************!*\
  !*** ./resources/js/layouts/App.vue ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _App_vue_vue_type_template_id_9087fe26___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./App.vue?vue&type=template&id=9087fe26& */ "./resources/js/layouts/App.vue?vue&type=template&id=9087fe26&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _App_vue_vue_type_template_id_9087fe26___WEBPACK_IMPORTED_MODULE_0__.render,
  _App_vue_vue_type_template_id_9087fe26___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/layouts/App.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/layouts/App.vue?vue&type=template&id=9087fe26&":
/*!*********************************************************************!*\
  !*** ./resources/js/layouts/App.vue?vue&type=template&id=9087fe26& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_9087fe26___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_9087fe26___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_9087fe26___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./App.vue?vue&type=template&id=9087fe26& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/App.vue?vue&type=template&id=9087fe26&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/App.vue?vue&type=template&id=9087fe26&":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/App.vue?vue&type=template&id=9087fe26& ***!
  \************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _vm._m(0),
    _vm._v(" "),
    _vm._m(1),
    _vm._v(" "),
    _vm._m(2),
    _vm._v(" "),
    _c("div", { staticClass: "header-wrapper cus-transition" }, [
      _c("nav", { staticClass: "navbar navbar-expand-lg main-nav" }, [
        _c(
          "div",
          { staticClass: "container-fluid" },
          [
            _vm._m(3),
            _vm._v(" "),
            _vm._m(4),
            _vm._v(" "),
            _vm._m(5),
            _vm._v(" "),
            _vm._m(6),
            _vm._v(" "),
            _vm._m(7),
            _vm._v(" "),
            _c("center", [
              _c("div", { staticClass: "search-product-box cus-transition" }, [
                _c("div", { staticClass: "searh-product-list" }, [
                  _c("div", { staticClass: "search-product" }, [
                    _c("div", { staticClass: "search-product-img" }, [
                      _c("a", { attrs: { href: "javascript:void(0)" } }, [
                        _c("img", {
                          attrs: {
                            src: "assets/img/medicines/1.webp",
                            alt: "product",
                            width: "100",
                          },
                        }),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "search-product-details" }, [
                      _c(
                        "a",
                        {
                          staticClass: "search-product-name",
                          attrs: { href: "javscript:void(0)" },
                        },
                        [
                          _vm._v(
                            "\n                                        Baby Care\n                                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c("span", { staticClass: "search-item-price d-none" }, [
                        _vm._v("৳200"),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "discount-box" }, [
                        _c(
                          "span",
                          { staticClass: "search-item-price after-discount" },
                          [_vm._v("৳100")]
                        ),
                        _vm._v(" "),
                        _c(
                          "del",
                          { staticClass: "search-item-price before-discount" },
                          [_vm._v("৳200")]
                        ),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "search-product" }, [
                    _c("div", { staticClass: "search-product-img" }, [
                      _c("a", { attrs: { href: "javascript:void(0)" } }, [
                        _c("img", {
                          attrs: {
                            src: "assets/img/medicines/1.webp",
                            alt: "product",
                            width: "100",
                          },
                        }),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "search-product-details" }, [
                      _c(
                        "a",
                        {
                          staticClass: "search-product-name",
                          attrs: { href: "javscript:void(0)" },
                        },
                        [
                          _vm._v(
                            "\n                                        Baby Care\n                                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c("span", { staticClass: "search-item-price d-none" }, [
                        _vm._v("৳200"),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "discount-box" }, [
                        _c(
                          "span",
                          { staticClass: "search-item-price after-discount" },
                          [_vm._v("৳100")]
                        ),
                        _vm._v(" "),
                        _c(
                          "del",
                          { staticClass: "search-item-price before-discount" },
                          [_vm._v("৳200")]
                        ),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "search-product" }, [
                    _c("div", { staticClass: "search-product-img" }, [
                      _c("a", { attrs: { href: "javascript:void(0)" } }, [
                        _c("img", {
                          attrs: {
                            src: "assets/img/medicines/1.webp",
                            alt: "product",
                            width: "100",
                          },
                        }),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "search-product-details" }, [
                      _c(
                        "a",
                        {
                          staticClass: "search-product-name",
                          attrs: { href: "javscript:void(0)" },
                        },
                        [
                          _vm._v(
                            "\n                                        Baby Care\n                                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c("span", { staticClass: "search-item-price d-none" }, [
                        _vm._v("৳200"),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "discount-box" }, [
                        _c(
                          "span",
                          { staticClass: "search-item-price after-discount" },
                          [_vm._v("৳100")]
                        ),
                        _vm._v(" "),
                        _c(
                          "del",
                          { staticClass: "search-item-price before-discount" },
                          [_vm._v("৳200")]
                        ),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "search-product" }, [
                    _c("div", { staticClass: "search-product-img" }, [
                      _c("a", { attrs: { href: "javascript:void(0)" } }, [
                        _c("img", {
                          attrs: {
                            src: "assets/img/medicines/1.webp",
                            alt: "product",
                            width: "100",
                          },
                        }),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "search-product-details" }, [
                      _c(
                        "a",
                        {
                          staticClass: "search-product-name",
                          attrs: { href: "javscript:void(0)" },
                        },
                        [
                          _vm._v(
                            "\n                                        Baby Care\n                                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c("span", { staticClass: "search-item-price d-none" }, [
                        _vm._v("৳200"),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "discount-box" }, [
                        _c(
                          "span",
                          { staticClass: "search-item-price after-discount" },
                          [_vm._v("৳100")]
                        ),
                        _vm._v(" "),
                        _c(
                          "del",
                          { staticClass: "search-item-price before-discount" },
                          [_vm._v("৳200")]
                        ),
                      ]),
                    ]),
                  ]),
                ]),
              ]),
            ]),
          ],
          1
        ),
      ]),
    ]),
    _vm._v(" "),
    _vm._m(8),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "right so-groups-sticky hidden-xs",
        attrs: { id: "so-groups" },
      },
      [
        _c(
          "a",
          {
            staticClass: "sticky-mycart",
            attrs: { "data-target": "popup", "data-popup": "#popup-mycart" },
          },
          [
            _c("i", { staticClass: "bi bi-handbag" }),
            _vm._v(" "),
            _c("span", [_vm._v("\n                ৳ 200\n            ")]),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { attrs: { id: "shopping-cart" } }, [
      _c("div", { staticClass: "cart-wrapper cus-transition shop-bag" }, [
        _c("div", { staticClass: "cart-container" }, [
          _c("div", { staticClass: "cart-inner" }, [
            _c("div", { staticClass: "cart-header" }, [
              _c("div", { staticClass: "cart-header-icon" }, [
                _c("img", {
                  attrs: {
                    src: "assets/img/cart/shopping-bag.png",
                    alt: "bag",
                    width: "40",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("span", { staticClass: "cart-item-count s-font-600" }, [
                _vm._v("15 ITEMS"),
              ]),
              _vm._v(" "),
              _c("span", { staticClass: "close-cart" }, [
                _vm._v(
                  "\n                            Close \n                        "
                ),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "cart-body" }, [
              _c("div", { staticClass: "cart-order-item" }, [
                _c("div", { staticClass: "quantity" }, [
                  _c("button", { staticClass: "plus-quantity" }, [_vm._v("+")]),
                  _vm._v(" "),
                  _c("span", [_vm._v("20")]),
                  _vm._v(" "),
                  _c("button", { staticClass: "minus-quantity" }, [
                    _vm._v("-"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "picture" }, [
                  _c("img", {
                    attrs: {
                      src: "assets/img/cart/online-shopping.png",
                      alt: "item",
                      width: "50",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "name" }, [
                  _c("span", [_vm._v("Baby Care")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "sub-text s-font-600" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("100")]),
                    _vm._v(" "),
                    _c("span", [_vm._v(" / 125gm")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-item-amount" }, [
                  _c("div", { staticClass: "total" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("200")]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "remove-item" }, [
                    _c("i", { staticClass: "bi bi-trash" }),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "cart-order-item" }, [
                _c("div", { staticClass: "quantity" }, [
                  _c("button", { staticClass: "plus-quantity" }, [_vm._v("+")]),
                  _vm._v(" "),
                  _c("span", [_vm._v("20")]),
                  _vm._v(" "),
                  _c("button", { staticClass: "minus-quantity" }, [
                    _vm._v("-"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "picture" }, [
                  _c("img", {
                    attrs: {
                      src: "assets/img/cart/online-shopping.png",
                      alt: "item",
                      width: "50",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "name" }, [
                  _c("span", [_vm._v("Baby Care")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "sub-text s-font-600" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("100")]),
                    _vm._v(" "),
                    _c("span", [_vm._v(" / 125gm")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-item-amount" }, [
                  _c("div", { staticClass: "total" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("200")]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "remove-item" }, [
                    _c("i", { staticClass: "bi bi-trash" }),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "cart-order-item" }, [
                _c("div", { staticClass: "quantity" }, [
                  _c("button", { staticClass: "plus-quantity" }, [_vm._v("+")]),
                  _vm._v(" "),
                  _c("span", [_vm._v("20")]),
                  _vm._v(" "),
                  _c("button", { staticClass: "minus-quantity" }, [
                    _vm._v("-"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "picture" }, [
                  _c("img", {
                    attrs: {
                      src: "assets/img/cart/online-shopping.png",
                      alt: "item",
                      width: "50",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "name" }, [
                  _c("span", [_vm._v("Baby Care")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "sub-text s-font-600" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("100")]),
                    _vm._v(" "),
                    _c("span", [_vm._v(" / 125gm")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-item-amount" }, [
                  _c("div", { staticClass: "total" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("200")]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "remove-item" }, [
                    _c("i", { staticClass: "bi bi-trash" }),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "cart-order-item" }, [
                _c("div", { staticClass: "quantity" }, [
                  _c("button", { staticClass: "plus-quantity" }, [_vm._v("+")]),
                  _vm._v(" "),
                  _c("span", [_vm._v("20")]),
                  _vm._v(" "),
                  _c("button", { staticClass: "minus-quantity" }, [
                    _vm._v("-"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "picture" }, [
                  _c("img", {
                    attrs: {
                      src: "assets/img/cart/online-shopping.png",
                      alt: "item",
                      width: "50",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "name" }, [
                  _c("span", [_vm._v("Baby Care")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "sub-text s-font-600" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("100")]),
                    _vm._v(" "),
                    _c("span", [_vm._v(" / 125gm")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-item-amount" }, [
                  _c("div", { staticClass: "total" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("200")]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "remove-item" }, [
                    _c("i", { staticClass: "bi bi-trash" }),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "cart-order-item" }, [
                _c("div", { staticClass: "quantity" }, [
                  _c("button", { staticClass: "plus-quantity" }, [_vm._v("+")]),
                  _vm._v(" "),
                  _c("span", [_vm._v("20")]),
                  _vm._v(" "),
                  _c("button", { staticClass: "minus-quantity" }, [
                    _vm._v("-"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "picture" }, [
                  _c("img", {
                    attrs: {
                      src: "assets/img/cart/online-shopping.png",
                      alt: "item",
                      width: "50",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "name" }, [
                  _c("span", [_vm._v("Baby Care")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "sub-text s-font-600" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("100")]),
                    _vm._v(" "),
                    _c("span", [_vm._v(" / 125gm")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-item-amount" }, [
                  _c("div", { staticClass: "total" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("200")]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "remove-item" }, [
                    _c("i", { staticClass: "bi bi-trash" }),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "cart-order-item" }, [
                _c("div", { staticClass: "quantity" }, [
                  _c("button", { staticClass: "plus-quantity" }, [_vm._v("+")]),
                  _vm._v(" "),
                  _c("span", [_vm._v("20")]),
                  _vm._v(" "),
                  _c("button", { staticClass: "minus-quantity" }, [
                    _vm._v("-"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "picture" }, [
                  _c("img", {
                    attrs: {
                      src: "assets/img/cart/online-shopping.png",
                      alt: "item",
                      width: "50",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "name" }, [
                  _c("span", [_vm._v("Baby Care")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "sub-text s-font-600" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("100")]),
                    _vm._v(" "),
                    _c("span", [_vm._v(" / 125gm")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-item-amount" }, [
                  _c("div", { staticClass: "total" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("200")]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "remove-item" }, [
                    _c("i", { staticClass: "bi bi-trash" }),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "cart-order-item" }, [
                _c("div", { staticClass: "quantity" }, [
                  _c("button", { staticClass: "plus-quantity" }, [_vm._v("+")]),
                  _vm._v(" "),
                  _c("span", [_vm._v("20")]),
                  _vm._v(" "),
                  _c("button", { staticClass: "minus-quantity" }, [
                    _vm._v("-"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "picture" }, [
                  _c("img", {
                    attrs: {
                      src: "assets/img/cart/online-shopping.png",
                      alt: "item",
                      width: "50",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "name" }, [
                  _c("span", [_vm._v("Baby Care")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "sub-text s-font-600" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("100")]),
                    _vm._v(" "),
                    _c("span", [_vm._v(" / 125gm")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-item-amount" }, [
                  _c("div", { staticClass: "total" }, [
                    _c("span", [_vm._v("৳")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("200")]),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "remove-item" }, [
                    _c("i", { staticClass: "bi bi-trash" }),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "cart-footer mb-2" }, [
              _c("div", { staticClass: "cart-total w-50" }, [
                _c("span", [_vm._v("Cart Total")]),
                _vm._v(" "),
                _c("strong", { staticClass: "text-dark" }, [
                  _vm._v(
                    "\n                                ৳ 750\n                            "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "d-block flex-grow-1",
                  attrs: { href: "cart.html" },
                },
                [
                  _c("button", { staticClass: "app-btn w-100 mt-0" }, [
                    _c("i", { staticClass: "bi bi-shopping-bag" }),
                    _vm._v(" View Cart"),
                  ]),
                ]
              ),
            ]),
          ]),
        ]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "background-backdrop fade" }),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { attrs: { id: "app-side-login" } }, [
      _c(
        "div",
        { staticClass: "cart-wrapper cus-transition login right-cart-close" },
        [
          _c("div", { staticClass: "cart-container" }, [
            _c("div", { staticClass: "cart-inner" }, [
              _c("div", { attrs: { id: "login-panel" } }, [
                _c("div", { staticClass: "cart-header" }, [
                  _c("div", { staticClass: "cart-header-icon" }, [
                    _c("img", {
                      attrs: {
                        src: "assets/img/core/login.png",
                        alt: "bag",
                        width: "40",
                      },
                    }),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "cart-item-count" }, [
                    _vm._v("Login"),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "close-cart" }, [
                    _vm._v(" Close "),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-body" }, [
                  _c("div", { staticClass: "login-form-wrap" }, [
                    _c("form", { attrs: { action: "" } }, [
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v("Email Or Phone"),
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          staticClass: "app-input form-control",
                          attrs: { type: "text" },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v("Password"),
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          staticClass: "app-input form-control",
                          attrs: { type: "text" },
                        }),
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "d-flex justify-content-between" },
                        [
                          _c("div", { staticClass: "form-group" }, [
                            _c("input", {
                              staticClass: "rem-check-input",
                              attrs: {
                                id: "vehicle1",
                                name: "vehicle1",
                                type: "checkbox",
                                value: "Bike",
                              },
                            }),
                            _vm._v(" "),
                            _c("label", { attrs: { for: "vehicle1" } }, [
                              _vm._v("Remember Me"),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "form-group" }, [
                            _c(
                              "a",
                              {
                                staticStyle: {
                                  "font-size": "15px",
                                  color: "rgb(90, 80, 230)!important",
                                },
                                attrs: { href: "javascript:void(0)" },
                              },
                              [
                                _vm._v(
                                  "\n                                                Forget Password\n                                            "
                                ),
                              ]
                            ),
                          ]),
                        ]
                      ),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("button", { staticClass: "w-100 app-btn" }, [
                          _vm._v("Login"),
                        ]),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "redirect-link text-center font-bold" },
                      [
                        _c("strong", { staticClass: "d-block mt-3" }, [
                          _vm._v(
                            "\n                                        New Here ?\n                                        "
                          ),
                          _c("i", {
                            staticClass: "bi bi-chevron-down d-block",
                          }),
                        ]),
                        _vm._v(" "),
                        _c(
                          "button",
                          { staticClass: "w-100 app-btn reg-trigger" },
                          [_vm._v("Create An Account")]
                        ),
                      ]
                    ),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "d-none", attrs: { id: "reg-panel" } }, [
                _c("div", { staticClass: "cart-header" }, [
                  _c("div", { staticClass: "cart-header-icon" }, [
                    _c("img", {
                      attrs: {
                        src: "assets/img/core/login.png",
                        alt: "bag",
                        width: "40",
                      },
                    }),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "cart-item-count" }, [
                    _vm._v("Registration"),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "close-cart" }, [
                    _vm._v(
                      "\n                                Close \n                            "
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "cart-body" }, [
                  _c("div", { staticClass: "login-form-wrap" }, [
                    _c("form", { attrs: { action: "" } }, [
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [_vm._v("Name")]),
                        _vm._v(" "),
                        _c("input", {
                          staticClass: "app-input form-control",
                          attrs: { type: "text" },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [_vm._v("Email")]),
                        _vm._v(" "),
                        _c("input", {
                          staticClass: "app-input form-control",
                          attrs: { type: "text" },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [_vm._v("Phone")]),
                        _vm._v(" "),
                        _c("input", {
                          staticClass: "app-input form-control",
                          attrs: { type: "text" },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v("Password"),
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          staticClass: "app-input form-control",
                          attrs: { type: "text" },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v("Confirm Password"),
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          staticClass: "app-input form-control",
                          attrs: { type: "text" },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("strong", { staticClass: "mb-3" }, [
                        _vm._v("Address"),
                      ]),
                      _vm._v(" "),
                      _c("br"),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [_vm._v("City")]),
                        _vm._v(" "),
                        _c(
                          "select",
                          {
                            staticClass: "app-input form-control",
                            attrs: { name: "", id: "" },
                          },
                          [
                            _c("option", { attrs: { value: "" } }, [
                              _vm._v("--select city--"),
                            ]),
                            _vm._v(" "),
                            _c("option", { attrs: { value: "" } }, [
                              _vm._v("Dhaka"),
                            ]),
                          ]
                        ),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [_vm._v("Area")]),
                        _vm._v(" "),
                        _c(
                          "select",
                          {
                            staticClass: "app-input form-control",
                            attrs: { name: "", id: "" },
                          },
                          [
                            _c("option", { attrs: { value: "" } }, [
                              _vm._v("--select area--"),
                            ]),
                            _vm._v(" "),
                            _c("option", { attrs: { value: "" } }, [
                              _vm._v("Dhaka"),
                            ]),
                          ]
                        ),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v("Address"),
                        ]),
                        _vm._v(" "),
                        _c("textarea", {
                          staticClass: "app-input form-control",
                          attrs: { name: "", id: "", cols: "40", rows: "10" },
                        }),
                      ]),
                      _c("br"),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group" }, [
                        _c("button", { staticClass: "w-100 app-btn" }, [
                          _vm._v("Registration"),
                        ]),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "redirect-link text-center font-bold" },
                      [
                        _c("strong", { staticClass: "d-block mt-3" }, [
                          _vm._v(
                            "\n                            Already have account\n                            "
                          ),
                          _c("i", {
                            staticClass: "bi bi-chevron-down d-block",
                          }),
                        ]),
                        _vm._v(" "),
                        _c(
                          "button",
                          { staticClass: "w-100 app-btn login-trigger" },
                          [_vm._v("Login")]
                        ),
                      ]
                    ),
                  ]),
                ]),
              ]),
            ]),
          ]),
        ]
      ),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "sidebar navbar-toggler",
        attrs: {
          type: "button",
          "data-bs-toggle": "offcanvas",
          "data-bs-target": "#offcanvasExample",
          "aria-controls": "offcanvasExample",
        },
      },
      [
        _c(
          "div",
          {
            staticClass: "hamBergerMenuIcon",
            attrs: { "data-bs-target": "#offcanvasExample" },
          },
          [
            _c("div", { staticClass: "bar1" }),
            _vm._v(" "),
            _c("div", { staticClass: "bar2" }),
            _vm._v(" "),
            _c("div", { staticClass: "bar3" }),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "sidebar-collapse-btn bg-transparent d-lg-block d-none",
        attrs: { type: "button" },
      },
      [
        _c(
          "div",
          {
            staticClass: "hamBergerMenuIcon",
            attrs: { "data-bs-target": "#offcanvasExample" },
          },
          [
            _c("div", { staticClass: "bar1" }),
            _vm._v(" "),
            _c("div", {
              staticClass: "bar2",
              staticStyle: { width: "15px", "margin-left": "auto" },
            }),
            _vm._v(" "),
            _c("div", { staticClass: "bar3" }),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("a", { staticClass: "navbar-logo", attrs: { href: "#" } }, [
      _c("img", {
        attrs: { src: "assets/img/logo/logo.png", alt: "logo", width: "140" },
      }),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "navbar-toggler",
        attrs: {
          type: "button",
          "data-bs-toggle": "collapse",
          "data-bs-target": "#navbarSupportedContent",
          "aria-controls": "navbarSupportedContent",
          "aria-expanded": "false",
          "aria-label": "Toggle navigation",
        },
      },
      [
        _c(
          "div",
          {
            staticClass: "hamBergerMenuIcon",
            attrs: { "data-bs-target": "#offcanvasExample" },
          },
          [
            _c("div", { staticClass: "bar1" }),
            _vm._v(" "),
            _c("div", {
              staticClass: "bar2",
              staticStyle: { width: "15px", "margin-left": "auto" },
            }),
            _vm._v(" "),
            _c("div", { staticClass: "bar3" }),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "collapse navbar-collapse collapsed-nav nav-right-box",
        attrs: { id: "navbarSupportedContent" },
      },
      [
        _c("div", { staticClass: "search-form" }, [
          _c("form", [
            _c("div", { staticClass: "search input-group my-3 my-lg-0" }, [
              _c("input", {
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  placeholder: "Search Product",
                  "aria-label": "Search Product",
                  "aria-describedby": "button-addon2",
                },
              }),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("ul", { staticClass: "navbar-nav mb-2 mb-lg-0" }, [
          _c("li", { staticClass: "nav-item dropdown" }, [
            _c(
              "a",
              {
                staticClass: "nav-link dropdown-toggle language-dropdown",
                attrs: {
                  href: "#",
                  id: "navbarDropdown",
                  role: "button",
                  "data-bs-toggle": "dropdown",
                  "aria-expanded": "false",
                },
              },
              [
                _c("i", { staticClass: "bi bi-translate" }),
                _vm._v(" EN\n                                "),
                _c("i", { staticClass: "bi bi-chevron-down" }),
              ]
            ),
            _vm._v(" "),
            _c(
              "ul",
              {
                staticClass: "dropdown-menu dropdown-menu-end language-list",
                attrs: { "aria-labelledby": "navbarDropdown" },
              },
              [
                _c("li", [
                  _c(
                    "a",
                    { staticClass: "dropdown-item", attrs: { href: "#" } },
                    [_vm._v("EN")]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [_c("hr", { staticClass: "dropdown-divider" })]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    { staticClass: "dropdown-item", attrs: { href: "#" } },
                    [_vm._v("বাং")]
                  ),
                ]),
              ]
            ),
          ]),
          _vm._v(" "),
          _c("li", { staticClass: "nav-item" }, [
            _c("a", { staticClass: "nav-link", attrs: { href: "#" } }, [
              _c("i", { staticClass: "bi bi-question-lg" }),
              _vm._v(" Help"),
            ]),
          ]),
          _vm._v(" "),
          _c("li", { staticClass: "nav-item" }, [
            _c(
              "a",
              {
                staticClass: "nav-link login-trigger",
                attrs: { id: "login", href: "javascript:void(0)" },
              },
              [
                _c("i", { staticClass: "bi bi-lock" }),
                _vm._v(" Sign In\n                            "),
              ]
            ),
          ]),
          _vm._v(" "),
          _c("li", { staticClass: "nav-item" }, [
            _c(
              "a",
              {
                staticClass: "nav-link reg-part",
                attrs: { id: "login", href: "javascript:void(0)" },
              },
              [
                _c("i", { staticClass: "bi bi-lock" }),
                _vm._v(" Sign Up\n                            "),
              ]
            ),
          ]),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "app-wrap relative" }, [
      _c("div", { staticClass: "cate-sidebar" }, [
        _c(
          "div",
          {
            staticClass: "offcanvas offcanvas-start sidebar-nav",
            attrs: {
              tabindex: "-1",
              id: "offcanvasExample",
              "aria-labelledby": "offcanvasExampleLabel",
            },
          },
          [
            _c("div", { staticClass: "offcanvas-body p-0" }, [
              _c("nav", { staticClass: "navbar-light" }, [
                _c("ul", { staticClass: "navbar-nav " }, [
                  _c("li", { staticClass: "offer-nav-box" }, [
                    _c("img", {
                      staticClass: "sidenav-cate-img",
                      attrs: { src: "assets/img/cart/10.png", alt: "cate" },
                    }),
                    _vm._v(" "),
                    _c("div", { staticClass: "sidenav-cate-name-wrap" }, [
                      _c(
                        "a",
                        {
                          staticClass: "nav-link px-2 sidebar-link",
                          attrs: { href: "product.html" },
                        },
                        [
                          _c("span", [
                            _vm._v(
                              "\n                                            Offers\n                                            "
                            ),
                            _c(
                              "label",
                              {
                                staticClass: "badge badge-danger badge-outline",
                                attrs: { for: "" },
                              },
                              [_vm._v("20")]
                            ),
                          ]),
                        ]
                      ),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("img", {
                      staticClass: "sidenav-cate-img",
                      attrs: {
                        src: "assets/img/cart/online-shopping.png",
                        alt: "cate",
                      },
                    }),
                    _vm._v(" "),
                    _c("div", { staticClass: "sidenav-cate-name-wrap" }, [
                      _c(
                        "a",
                        {
                          staticClass: "nav-link px-2 sidebar-link",
                          attrs: { href: "product.html" },
                        },
                        [_c("span", [_vm._v("Popular")])]
                      ),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("img", {
                      staticClass: "sidenav-cate-img",
                      attrs: {
                        src: "assets/img/cart/shopping-bag.png",
                        alt: "cate",
                      },
                    }),
                    _vm._v(" "),
                    _c("div", { staticClass: "sidenav-cate-name-wrap" }, [
                      _c(
                        "a",
                        {
                          staticClass: "nav-link px-2 sidebar-link",
                          attrs: {
                            "data-bs-toggle": "collapse",
                            href: "#babycare",
                            role: "button",
                            "aria-expanded": "false",
                            "aria-controls": "babycare",
                          },
                        },
                        [
                          _c("span", [_vm._v("Food")]),
                          _vm._v(" "),
                          _c("span", { staticClass: "me-2" }, [
                            _c("i", { staticClass: "bi bi-chevron-right" }),
                          ]),
                        ]
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "collapse", attrs: { id: "babycare" } },
                      [
                        _c("ul", { staticClass: "navbar-nav ms-3" }, [
                          _c("li", [
                            _c(
                              "div",
                              { staticClass: "sidenav-cate-name-wrap" },
                              [
                                _c(
                                  "a",
                                  {
                                    staticClass: "nav-link px-2 sidebar-link",
                                    attrs: {
                                      "data-bs-toggle": "collapse",
                                      href: "#newborn",
                                      role: "button",
                                      "aria-expanded": "false",
                                      "aria-controls": "newborn",
                                    },
                                  },
                                  [
                                    _c("span", [_vm._v("Fruits & Vegetables")]),
                                    _vm._v(" "),
                                    _c("span", { staticClass: "me-2" }, [
                                      _c("i", {
                                        staticClass: "bi bi-chevron-right",
                                      }),
                                    ]),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass: "collapse",
                                attrs: { id: "newborn" },
                              },
                              [
                                _c("ul", { staticClass: "navbar-nav ms-3" }, [
                                  _c("li", [
                                    _c(
                                      "a",
                                      {
                                        staticClass: "nav-link px-2",
                                        attrs: { href: "category.html" },
                                      },
                                      [
                                        _c("span", { staticClass: "me-2" }),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v("Newborn Essentials"),
                                        ]),
                                      ]
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("li", [
                                    _c(
                                      "a",
                                      {
                                        staticClass: "nav-link px-2",
                                        attrs: { href: "category.html" },
                                      },
                                      [
                                        _c("span", { staticClass: "me-2" }),
                                        _vm._v(" "),
                                        _c("span", [_vm._v("Diapers & Wipes")]),
                                      ]
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("li", [
                                    _c(
                                      "a",
                                      {
                                        staticClass: "nav-link px-2",
                                        attrs: { href: "category.html" },
                                      },
                                      [
                                        _c("span", { staticClass: "me-2" }),
                                        _vm._v(" "),
                                        _c("span", [_vm._v("Feeders")]),
                                      ]
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("li", [
                                    _c(
                                      "a",
                                      {
                                        staticClass: "nav-link px-2",
                                        attrs: { href: "category.html" },
                                      },
                                      [
                                        _c("span", { staticClass: "me-2" }),
                                        _vm._v(" "),
                                        _c("span", [_vm._v("Fooding")]),
                                      ]
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("li", [
                                    _c(
                                      "a",
                                      {
                                        staticClass: "nav-link px-2",
                                        attrs: { href: "category.html" },
                                      },
                                      [
                                        _c("span", { staticClass: "me-2" }),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v("Baby Accessories"),
                                        ]),
                                      ]
                                    ),
                                  ]),
                                ]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("li", [
                            _c(
                              "a",
                              {
                                staticClass: "nav-link px-2",
                                attrs: { href: "category.html" },
                              },
                              [
                                _c("span", { staticClass: "me-2" }),
                                _vm._v(" "),
                                _c("span", [_vm._v("Diapers & Wipes")]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("li", [
                            _c(
                              "a",
                              {
                                staticClass: "nav-link px-2",
                                attrs: { href: "category.html" },
                              },
                              [
                                _c("span", { staticClass: "me-2" }),
                                _vm._v(" "),
                                _c("span", [_vm._v("Feeders")]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("li", [
                            _c(
                              "a",
                              {
                                staticClass: "nav-link px-2",
                                attrs: { href: "category.html" },
                              },
                              [
                                _c("span", { staticClass: "me-2" }),
                                _vm._v(" "),
                                _c("span", [_vm._v("Fooding")]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("li", [
                            _c(
                              "a",
                              {
                                staticClass: "nav-link px-2",
                                attrs: { href: "category.html" },
                              },
                              [
                                _c("span", { staticClass: "me-2" }),
                                _vm._v(" "),
                                _c("span", [_vm._v("Baby Accessories")]),
                              ]
                            ),
                          ]),
                        ]),
                      ]
                    ),
                  ]),
                ]),
              ]),
            ]),
          ]
        ),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "app-content" }, [
        _c("div", { staticClass: "app-content-inner" }, [
          _c("div", { staticClass: "home-landing-banner" }, [
            _c("img", {
              attrs: { src: "assets/img/banner/1.webp", alt: "banner" },
            }),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "service-system" }, [
            _c("div", { staticClass: "container" }, [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-md-4" }, [
                  _c("div", { staticClass: "service" }, [
                    _c("div", { staticClass: "service-icon" }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/core/7.png",
                          alt: "services",
                          height: "50",
                          width: "50",
                        },
                      }),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "service-content" }, [
                      _c("b", [_vm._v("Big Saving")]),
                      _vm._v(" "),
                      _c("span", [_vm._v("At Lowest Price")]),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-md-4" }, [
                  _c("div", { staticClass: "service" }, [
                    _c("div", { staticClass: "service-icon" }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/core/6.png",
                          alt: "services",
                          height: "50",
                          width: "50",
                        },
                      }),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "service-content" }, [
                      _c("b", [_vm._v("24 Hour Support")]),
                      _vm._v(" "),
                      _c("span", [_vm._v("In Save Hand")]),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-md-4" }, [
                  _c("div", { staticClass: "service" }, [
                    _c("div", { staticClass: "service-icon" }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/core/5.png",
                          alt: "services",
                          height: "50",
                          width: "50",
                        },
                      }),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "service-content" }, [
                      _c("b", [_vm._v("Flexible Delivery")]),
                      _vm._v(" "),
                      _c("span", [_vm._v("on order over $40")]),
                    ]),
                  ]),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "discount-offer-refer" }, [
            _c("div", { staticClass: "container" }, [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-6 col-md-6" }, [
                  _c("a", { attrs: { href: "javascript:void(0)" } }, [
                    _c("div", { staticClass: "discount-offer" }, [
                      _c("img", {
                        attrs: { src: "assets/img/offer/5.jpg", alt: "offer" },
                      }),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-md-6" }, [
                  _c("a", { attrs: { href: "javascript:void(0)" } }, [
                    _c("div", { staticClass: "discount-offer" }, [
                      _c("img", {
                        attrs: { src: "assets/img/offer/6.jpg", alt: "offer" },
                      }),
                    ]),
                  ]),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "item-categories-area" }, [
            _c("div", { staticClass: "container" }, [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-md-12" }, [
                  _c("h3", { staticClass: "sectitle" }, [
                    _vm._v("Our Product Categories"),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "row justify-content-center" }, [
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/3.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices \n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/4.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/5.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/6.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/7.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/8.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/2.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/1.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories cus-transition" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/1.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/1.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/2.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-xl-2 col-lg-3 col-md-3" }, [
                  _c("div", { staticClass: "item-categories" }, [
                    _c(
                      "a",
                      {
                        staticClass: "item-category-img bg-white",
                        attrs: { href: "category.html" },
                      },
                      [
                        _c("img", {
                          staticClass: "img-fluid",
                          attrs: {
                            src: "assets/img/category/1.png",
                            alt: "category",
                            width: "150",
                          },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "item-category-info",
                        attrs: { href: "category.html" },
                      },
                      [
                        _vm._v(
                          "\n                                        Healthcare Devices\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "testimonials " }, [
            _c("div", { staticClass: "container " }, [
              _c("div", { staticClass: "row " }, [
                _c("div", { staticClass: "col-md-12 " }, [
                  _c("h2", { staticClass: "sectitle " }, [
                    _vm._v("What our clients are saying"),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "row " }, [
                _c("div", { staticClass: "col-md-12 " }, [
                  _c("div", { staticClass: "slider-container " }, [
                    _c("div", { staticClass: "slider " }, [
                      _c("div", { staticClass: "slide-box " }, [
                        _c("p", { staticClass: "comment " }, [
                          _vm._v(
                            "\n                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                                            "
                          ),
                        ]),
                        _vm._v(" "),
                        _c("img", {
                          attrs: {
                            src: "https://images.unsplash.com/photo-1595152452543-e5fc28ebc2b8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=80 ",
                          },
                        }),
                        _vm._v(" "),
                        _c("h3", { staticClass: "name " }, [
                          _vm._v("Albert Sinelly"),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "slide-box " }, [
                        _c("p", { staticClass: "comment " }, [
                          _vm._v(
                            "\n                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                                            "
                          ),
                        ]),
                        _vm._v(" "),
                        _c("img", {
                          attrs: {
                            src: "https://images.unsplash.com/photo-1627541718143-1adc1b582e62?ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8bXVzbGltfGVufDB8MnwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
                          },
                        }),
                        _vm._v(" "),
                        _c("h3", { staticClass: "name " }, [
                          _vm._v("Hirok Meryam"),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "slide-box " }, [
                        _c("p", { staticClass: "comment " }, [
                          _vm._v(
                            "\n                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                                            "
                          ),
                        ]),
                        _vm._v(" "),
                        _c("img", {
                          attrs: {
                            src: "https://images.unsplash.com/photo-1610216705422-caa3fcb6d158?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzJ8fGZhY2V8ZW58MHwyfDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
                          },
                        }),
                        _vm._v(" "),
                        _c("h3", { staticClass: "name " }, [
                          _vm._v("Sebastian Sert"),
                        ]),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "control-slider btn-left ",
                        attrs: { href: "#! " },
                      },
                      [_c("i", { staticClass: "bi bi-chevron-left " })]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "control-slider btn-right ",
                        attrs: { href: "#! " },
                      },
                      [_c("i", { staticClass: "bi bi-chevron-right " })]
                    ),
                  ]),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("footer", { attrs: { id: "footer " } }, [
            _c("div", { staticClass: "footer-top " }, [
              _c("div", { staticClass: "row " }, [
                _c("div", { staticClass: "col-12 col-md-6 " }, [
                  _c("div", { staticClass: "footer-widget " }, [
                    _c("div", { staticClass: "footer-logo " }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/logo/logo.png ",
                          alt: "logo ",
                          width: "200 ",
                        },
                      }),
                    ]),
                    _vm._v(" "),
                    _c("p", { staticClass: "mb-0 " }, [
                      _vm._v(
                        "\n                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, cupiditate a quisquam vel minus officiis corrupti voluptatum aliquid laborum tempora fuga placeat voluptas, quidem veniam repellendus soluta optio quia eaque!\n                                    "
                      ),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-md-3 " }, [
                  _c("div", { staticClass: "footer-widget " }, [
                    _c(
                      "div",
                      { staticClass: "footer-widget-title s-font-600" },
                      [_vm._v("Customer Service")]
                    ),
                    _vm._v(" "),
                    _c("ul", { staticClass: "footer-menu " }, [
                      _c("li", [
                        _c("a", { attrs: { href: "javascript:void() " } }, [
                          _vm._v("Contact Us"),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("li", [
                        _c("a", { attrs: { href: "javascript:void() " } }, [
                          _vm._v("Faq"),
                        ]),
                      ]),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6 col-md-3 " }, [
                  _c("div", { staticClass: "footer-widget " }, [
                    _c(
                      "div",
                      { staticClass: "footer-widget-title s-font-600" },
                      [_vm._v("About")]
                    ),
                    _vm._v(" "),
                    _c("ul", { staticClass: "footer-menu " }, [
                      _c("li", [
                        _c("a", { attrs: { href: "javascript:void() " } }, [
                          _vm._v("Privacy Policy"),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("li", [
                        _c("a", { attrs: { href: "javascript:void() " } }, [
                          _vm._v("Terms of Use"),
                        ]),
                      ]),
                    ]),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "footer-bottom " }, [
              _c("div", { staticClass: "contact-section " }, [
                _c("div", { staticClass: "phone-or-email s-font-500" }, [
                  _c("span", [
                    _c("img", {
                      attrs: {
                        src: "assets/img/cart/phone.png ",
                        alt: "phone ",
                        width: "20 ",
                      },
                    }),
                  ]),
                  _vm._v(" "),
                  _c("span", [
                    _vm._v(
                      "\n                                        198789\n                                    "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "email " }, [
                    _vm._v("\n                                    or email "),
                    _c("strong", [_vm._v("support@sombob.com")]),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "sociaol-section " }, [
                _c("ul", { staticClass: "social-icons " }, [
                  _c("li", [
                    _c("a", { attrs: { href: "javascript:void(0) " } }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/social/facebook.png ",
                          alt: "facebook ",
                          width: "20 ",
                        },
                      }),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "javascript:void(0) " } }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/social/twitter.png ",
                          alt: "twitter ",
                          width: "20 ",
                        },
                      }),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "javascript:void(0) " } }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/social/youtube.png ",
                          alt: "youtube ",
                          width: "20 ",
                        },
                      }),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "javascript:void(0) " } }, [
                      _c("img", {
                        attrs: {
                          src: "assets/img/social/instagram.png ",
                          alt: "instagram ",
                          width: "20 ",
                        },
                      }),
                    ]),
                  ]),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js":
/*!********************************************************************!*\
  !*** ./node_modules/vue-loader/lib/runtime/componentNormalizer.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ normalizeComponent)
/* harmony export */ });
/* globals __VUE_SSR_CONTEXT__ */

// IMPORTANT: Do NOT use ES2015 features in this file (except for modules).
// This module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle.

function normalizeComponent (
  scriptExports,
  render,
  staticRenderFns,
  functionalTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier, /* server only */
  shadowMode /* vue-cli only */
) {
  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (render) {
    options.render = render
    options.staticRenderFns = staticRenderFns
    options._compiled = true
  }

  // functional template
  if (functionalTemplate) {
    options.functional = true
  }

  // scopedId
  if (scopeId) {
    options._scopeId = 'data-v-' + scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = shadowMode
      ? function () {
        injectStyles.call(
          this,
          (options.functional ? this.parent : this).$root.$options.shadowRoot
        )
      }
      : injectStyles
  }

  if (hook) {
    if (options.functional) {
      // for template-only hot-reload because in that case the render fn doesn't
      // go through the normalizer
      options._injectStyles = hook
      // register for functional component in vue file
      var originalRender = options.render
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return originalRender(h, context)
      }
    } else {
      // inject component registration as beforeCreate hook
      var existing = options.beforeCreate
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    }
  }

  return {
    exports: scriptExports,
    options: options
  }
}


/***/ })

}]);