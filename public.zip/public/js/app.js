/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*****************************!*\
  !*** ./resources/js/app.js ***!
  \*****************************/
// require('./bootstrap')
// import Vue from 'vue'
// window.Vue = require('vue').default;
// import VueAxios from 'vue-axios'
// Vue.use(VueAxios, axios)
// import VueLazyload from 'vue-lazyload'
// Vue.use(VueLazyload)
// import ProductZoomer from 'vue-product-zoomer'
// Vue.use(ProductZoomer)
// import User from './Helpers/User';
// window.User = User;
// Vue.use(require('vue-moment'));
// import VueCarousel from 'vue-carousel';
// Vue.use(VueCarousel);
// import Notifications from 'vue-notification'
// Vue.use(Notifications)
// Vue.use(VueLazyload, {
//   preLoad: 1.3,
//   error: '/image.svg',
//   loading: '/preloader.gif',
//   attempt: 1,
//   listenEvents: [ 'scroll' ]
// })
// Vue.component("main-app", () =>
//     import(
//          "./layouts/App.vue"
//     )
// );
// Vue.component("sidebar", () =>
//     import(
//          "./components/Sidebar.vue"
//     )
// );
// Vue.component('pagination', require('laravel-vue-pagination'));
// window.base_path = window.location.origin;
// import router from "./router";
// import store from "./store/store";
// Vue.prototype.router = router;
// Vue.prototype.goBack = () => {
//     router.go(-1);
// };
// const app = new Vue({
//     el: '#app',
//     router,
//     store,
// }).$mount('#app');
/******/ })()
;