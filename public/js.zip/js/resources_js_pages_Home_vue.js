"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_pages_Home_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeBanner.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeBanner.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: "Banner",
  props: ['banner']
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeProductCategory.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeProductCategory.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'ProductSubcategory',
  props: ['categories', 'categoryType'],
  computed: {
    currentRouteName: function currentRouteName() {
      return this.$route.name;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Home.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Home.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_homes_HomeBanner_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/homes/HomeBanner.vue */ "./resources/js/components/homes/HomeBanner.vue");
/* harmony import */ var _components_homes_HomeService_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/homes/HomeService.vue */ "./resources/js/components/homes/HomeService.vue");
/* harmony import */ var _components_homes_HomeOffer_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/homes/HomeOffer.vue */ "./resources/js/components/homes/HomeOffer.vue");
/* harmony import */ var _components_homes_HomeProductCategory_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/homes/HomeProductCategory.vue */ "./resources/js/components/homes/HomeProductCategory.vue");
/* harmony import */ var _components_homes_HomeTestimonial_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/homes/HomeTestimonial.vue */ "./resources/js/components/homes/HomeTestimonial.vue");
/* harmony import */ var _components_Footer_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Footer.vue */ "./resources/js/components/Footer.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'Home',
  components: {
    Banner: _components_homes_HomeBanner_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    Services: _components_homes_HomeService_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    Offers: _components_homes_HomeOffer_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    ProductCategories: _components_homes_HomeProductCategory_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    Testimonial: _components_homes_HomeTestimonial_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    Footer: _components_Footer_vue__WEBPACK_IMPORTED_MODULE_5__["default"]
  },
  data: function data() {
    return {
      banner: '',
      is_mobile: window.innerWidth <= 950
    };
  },
  methods: {
    getBanner: function getBanner() {
      var _this = this;

      axios.get('api/v1/site-media').then(function (response) {
        if (response.status == 200) {
          _this.banner = response.data[0].home_banner;
        }
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  mounted: function mounted() {
    this.getBanner();
  },
  computed: {
    user: function user() {
      return this.$store.getters.getUser;
    }
  }
});

/***/ }),

/***/ "./resources/js/components/Footer.vue":
/*!********************************************!*\
  !*** ./resources/js/components/Footer.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Footer_vue_vue_type_template_id_61a7c374___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Footer.vue?vue&type=template&id=61a7c374& */ "./resources/js/components/Footer.vue?vue&type=template&id=61a7c374&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _Footer_vue_vue_type_template_id_61a7c374___WEBPACK_IMPORTED_MODULE_0__.render,
  _Footer_vue_vue_type_template_id_61a7c374___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/Footer.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/homes/HomeBanner.vue":
/*!******************************************************!*\
  !*** ./resources/js/components/homes/HomeBanner.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _HomeBanner_vue_vue_type_template_id_04423dd1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomeBanner.vue?vue&type=template&id=04423dd1& */ "./resources/js/components/homes/HomeBanner.vue?vue&type=template&id=04423dd1&");
/* harmony import */ var _HomeBanner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./HomeBanner.vue?vue&type=script&lang=js& */ "./resources/js/components/homes/HomeBanner.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _HomeBanner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _HomeBanner_vue_vue_type_template_id_04423dd1___WEBPACK_IMPORTED_MODULE_0__.render,
  _HomeBanner_vue_vue_type_template_id_04423dd1___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/homes/HomeBanner.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/homes/HomeOffer.vue":
/*!*****************************************************!*\
  !*** ./resources/js/components/homes/HomeOffer.vue ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _HomeOffer_vue_vue_type_template_id_75f5c747___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomeOffer.vue?vue&type=template&id=75f5c747& */ "./resources/js/components/homes/HomeOffer.vue?vue&type=template&id=75f5c747&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _HomeOffer_vue_vue_type_template_id_75f5c747___WEBPACK_IMPORTED_MODULE_0__.render,
  _HomeOffer_vue_vue_type_template_id_75f5c747___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/homes/HomeOffer.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/homes/HomeProductCategory.vue":
/*!***************************************************************!*\
  !*** ./resources/js/components/homes/HomeProductCategory.vue ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _HomeProductCategory_vue_vue_type_template_id_272c6fb8_v_if_categories___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories& */ "./resources/js/components/homes/HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories&");
/* harmony import */ var _HomeProductCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./HomeProductCategory.vue?vue&type=script&lang=js& */ "./resources/js/components/homes/HomeProductCategory.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _HomeProductCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _HomeProductCategory_vue_vue_type_template_id_272c6fb8_v_if_categories___WEBPACK_IMPORTED_MODULE_0__.render,
  _HomeProductCategory_vue_vue_type_template_id_272c6fb8_v_if_categories___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/homes/HomeProductCategory.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/homes/HomeService.vue":
/*!*******************************************************!*\
  !*** ./resources/js/components/homes/HomeService.vue ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _HomeService_vue_vue_type_template_id_f5465340___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomeService.vue?vue&type=template&id=f5465340& */ "./resources/js/components/homes/HomeService.vue?vue&type=template&id=f5465340&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _HomeService_vue_vue_type_template_id_f5465340___WEBPACK_IMPORTED_MODULE_0__.render,
  _HomeService_vue_vue_type_template_id_f5465340___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/homes/HomeService.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/homes/HomeTestimonial.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/homes/HomeTestimonial.vue ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _HomeTestimonial_vue_vue_type_template_id_0c79a46c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomeTestimonial.vue?vue&type=template&id=0c79a46c& */ "./resources/js/components/homes/HomeTestimonial.vue?vue&type=template&id=0c79a46c&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _HomeTestimonial_vue_vue_type_template_id_0c79a46c___WEBPACK_IMPORTED_MODULE_0__.render,
  _HomeTestimonial_vue_vue_type_template_id_0c79a46c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/homes/HomeTestimonial.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Home.vue":
/*!*************************************!*\
  !*** ./resources/js/pages/Home.vue ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Home_vue_vue_type_template_id_b3c5cf30___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Home.vue?vue&type=template&id=b3c5cf30& */ "./resources/js/pages/Home.vue?vue&type=template&id=b3c5cf30&");
/* harmony import */ var _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Home.vue?vue&type=script&lang=js& */ "./resources/js/pages/Home.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Home_vue_vue_type_template_id_b3c5cf30___WEBPACK_IMPORTED_MODULE_0__.render,
  _Home_vue_vue_type_template_id_b3c5cf30___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Home.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/homes/HomeBanner.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/homes/HomeBanner.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeBanner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./HomeBanner.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeBanner.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeBanner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/homes/HomeProductCategory.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/homes/HomeProductCategory.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeProductCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./HomeProductCategory.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeProductCategory.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeProductCategory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Home.vue?vue&type=script&lang=js&":
/*!**************************************************************!*\
  !*** ./resources/js/pages/Home.vue?vue&type=script&lang=js& ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Home.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Home.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/Footer.vue?vue&type=template&id=61a7c374&":
/*!***************************************************************************!*\
  !*** ./resources/js/components/Footer.vue?vue&type=template&id=61a7c374& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_61a7c374___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_61a7c374___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_61a7c374___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Footer.vue?vue&type=template&id=61a7c374& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Footer.vue?vue&type=template&id=61a7c374&");


/***/ }),

/***/ "./resources/js/components/homes/HomeBanner.vue?vue&type=template&id=04423dd1&":
/*!*************************************************************************************!*\
  !*** ./resources/js/components/homes/HomeBanner.vue?vue&type=template&id=04423dd1& ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeBanner_vue_vue_type_template_id_04423dd1___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeBanner_vue_vue_type_template_id_04423dd1___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeBanner_vue_vue_type_template_id_04423dd1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./HomeBanner.vue?vue&type=template&id=04423dd1& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeBanner.vue?vue&type=template&id=04423dd1&");


/***/ }),

/***/ "./resources/js/components/homes/HomeOffer.vue?vue&type=template&id=75f5c747&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/homes/HomeOffer.vue?vue&type=template&id=75f5c747& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeOffer_vue_vue_type_template_id_75f5c747___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeOffer_vue_vue_type_template_id_75f5c747___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeOffer_vue_vue_type_template_id_75f5c747___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./HomeOffer.vue?vue&type=template&id=75f5c747& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeOffer.vue?vue&type=template&id=75f5c747&");


/***/ }),

/***/ "./resources/js/components/homes/HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories&":
/*!**************************************************************************************************************!*\
  !*** ./resources/js/components/homes/HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories& ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeProductCategory_vue_vue_type_template_id_272c6fb8_v_if_categories___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeProductCategory_vue_vue_type_template_id_272c6fb8_v_if_categories___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeProductCategory_vue_vue_type_template_id_272c6fb8_v_if_categories___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories&");


/***/ }),

/***/ "./resources/js/components/homes/HomeService.vue?vue&type=template&id=f5465340&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/homes/HomeService.vue?vue&type=template&id=f5465340& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeService_vue_vue_type_template_id_f5465340___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeService_vue_vue_type_template_id_f5465340___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeService_vue_vue_type_template_id_f5465340___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./HomeService.vue?vue&type=template&id=f5465340& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeService.vue?vue&type=template&id=f5465340&");


/***/ }),

/***/ "./resources/js/components/homes/HomeTestimonial.vue?vue&type=template&id=0c79a46c&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/homes/HomeTestimonial.vue?vue&type=template&id=0c79a46c& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeTestimonial_vue_vue_type_template_id_0c79a46c___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeTestimonial_vue_vue_type_template_id_0c79a46c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomeTestimonial_vue_vue_type_template_id_0c79a46c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./HomeTestimonial.vue?vue&type=template&id=0c79a46c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeTestimonial.vue?vue&type=template&id=0c79a46c&");


/***/ }),

/***/ "./resources/js/pages/Home.vue?vue&type=template&id=b3c5cf30&":
/*!********************************************************************!*\
  !*** ./resources/js/pages/Home.vue?vue&type=template&id=b3c5cf30& ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_b3c5cf30___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_b3c5cf30___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_b3c5cf30___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Home.vue?vue&type=template&id=b3c5cf30& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Home.vue?vue&type=template&id=b3c5cf30&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Footer.vue?vue&type=template&id=61a7c374&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Footer.vue?vue&type=template&id=61a7c374& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("footer", { attrs: { id: "footer " } }, [
      _c("div", { staticClass: "footer-top " }, [
        _c("div", { staticClass: "row " }, [
          _c("div", { staticClass: "col-12 col-md-6 " }, [
            _c("div", { staticClass: "footer-widget " }, [
              _c("div", { staticClass: "footer-logo " }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/logo/logo.png ",
                    alt: "logo ",
                    width: "200 ",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("p", { staticClass: "mb-0 " }, [
                _vm._v(
                  "\n                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, cupiditate a quisquam vel minus officiis corrupti voluptatum aliquid laborum tempora fuga placeat voluptas, quidem veniam repellendus soluta optio quia eaque!\n                    "
                ),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-6 col-md-3 " }, [
            _c("div", { staticClass: "footer-widget " }, [
              _c("div", { staticClass: "footer-widget-title s-font-600" }, [
                _vm._v("Customer Service"),
              ]),
              _vm._v(" "),
              _c("ul", { staticClass: "footer-menu " }, [
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Contact Us"),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Faq"),
                  ]),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-6 col-md-3 " }, [
            _c("div", { staticClass: "footer-widget " }, [
              _c("div", { staticClass: "footer-widget-title s-font-600" }, [
                _vm._v("About"),
              ]),
              _vm._v(" "),
              _c("ul", { staticClass: "footer-menu " }, [
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Privacy Policy"),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Terms of Use"),
                  ]),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "footer-bottom " }, [
        _c("div", { staticClass: "contact-section " }, [
          _c("div", { staticClass: "phone-or-email s-font-500" }, [
            _c("span", [
              _c("img", {
                attrs: {
                  src: "/frontend/img/cart/phone.png ",
                  alt: "phone ",
                  width: "20 ",
                },
              }),
            ]),
            _vm._v(" "),
            _c("span", [
              _vm._v("\n                        198789\n                    "),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "email " }, [
              _vm._v("\n                    or email "),
              _c("strong", [_vm._v("support@sombob.com")]),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "sociaol-section " }, [
          _c("ul", { staticClass: "social-icons " }, [
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/facebook.png ",
                    alt: "facebook ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/twitter.png ",
                    alt: "twitter ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/youtube.png ",
                    alt: "youtube ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/instagram.png ",
                    alt: "instagram ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeBanner.vue?vue&type=template&id=04423dd1&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeBanner.vue?vue&type=template&id=04423dd1& ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("lazy-component", [
    _c(
      "div",
      {
        staticClass: "home-landing-banner",
        staticStyle: { "background-color": "rgb(217 200 154)" },
      },
      [
        _c("img", {
          attrs: {
            src: _vm.banner ? "storage/uploads/media/" + _vm.banner : "",
            alt: "banner",
          },
        }),
      ]
    ),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeOffer.vue?vue&type=template&id=75f5c747&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeOffer.vue?vue&type=template&id=75f5c747& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "discount-offer-refer" }, [
      _c("div", { staticClass: "row justify-content-center" }, [
        _c("div", { staticClass: "col-6 col-md-6" }, [
          _c("a", { attrs: { href: "javascript:void(0)" } }, [
            _c("div", { staticClass: "discount-offer text-center" }, [
              _c("img", {
                attrs: { src: "/frontend/img/offer/5.jpg", alt: "offer" },
              }),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-6 col-md-6 text-center" }, [
          _c("a", { attrs: { href: "javascript:void(0)" } }, [
            _c("div", { staticClass: "discount-offer" }, [
              _c("img", {
                attrs: { src: "/frontend/img/offer/6.jpg", alt: "offer" },
              }),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories&":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeProductCategory.vue?vue&type=template&id=272c6fb8&v-if=categories& ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "item-categories-area" }, [
    _c("div", { staticClass: "container-fluid" }, [
      this.currentRouteName == "home"
        ? _c(
            "div",
            { staticClass: "row justify-content-center" },
            _vm._l(this.$store.state.categories, function (category) {
              return _c(
                "div",
                {
                  key: category.id,
                  staticClass: "col-6 col-xl-2 col-lg-3 col-md-3",
                },
                [
                  _c(
                    "div",
                    { staticClass: "item-categories cus-transition" },
                    [
                      _c(
                        "router-link",
                        {
                          staticClass: "d-block",
                          attrs: { to: "/" + category.slug },
                        },
                        [
                          _c(
                            "div",
                            { staticClass: "item-category-img bg-white" },
                            [
                              _c("img", {
                                staticClass: "img-fluid",
                                attrs: {
                                  src:
                                    "/storage/uploads/product/category/" +
                                    category.image,
                                  alt: "category",
                                  width: "150",
                                },
                              }),
                            ]
                          ),
                          _vm._v(" "),
                          _c("div", { staticClass: "item-category-info" }, [
                            _vm._v(
                              "\n                            " +
                                _vm._s(category.name) +
                                "\n                        "
                            ),
                          ]),
                        ]
                      ),
                    ],
                    1
                  ),
                ]
              )
            }),
            0
          )
        : _c(
            "div",
            { staticClass: "row justify-content-center" },
            _vm._l(_vm.categories.categories, function (category) {
              return _c(
                "div",
                {
                  key: category.id,
                  staticClass: "col-6 col-xl-2 col-lg-3 col-md-3",
                },
                [
                  _vm.categoryType == "sub"
                    ? _c("div", [
                        _c(
                          "div",
                          { staticClass: "item-categories cus-transition" },
                          [
                            _c(
                              "router-link",
                              {
                                staticClass: "d-block",
                                attrs: {
                                  to: "/sub-sub-category/" + category.slug,
                                },
                              },
                              [
                                _c(
                                  "div",
                                  { staticClass: "item-category-img bg-white" },
                                  [
                                    _c("img", {
                                      staticClass: "img-fluid",
                                      attrs: {
                                        src:
                                          "/storage/uploads/product/category/" +
                                          category.image,
                                        alt: "category",
                                        width: "150",
                                      },
                                    }),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "item-category-info" },
                                  [
                                    _vm._v(
                                      "\n                                " +
                                        _vm._s(category.name) +
                                        "\n                            "
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ],
                          1
                        ),
                      ])
                    : _c("div", [
                        _c(
                          "div",
                          { staticClass: "item-categories cus-transition" },
                          [
                            _c(
                              "router-link",
                              {
                                staticClass: "d-block",
                                attrs: { to: "/sub-category/" + category.slug },
                              },
                              [
                                _c(
                                  "div",
                                  { staticClass: "item-category-img bg-white" },
                                  [
                                    _c("img", {
                                      staticClass: "img-fluid",
                                      attrs: {
                                        src:
                                          "/storage/uploads/product/category/" +
                                          category.image,
                                        alt: "category",
                                        width: "150",
                                      },
                                    }),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "item-category-info" },
                                  [
                                    _vm._v(
                                      "\n                                " +
                                        _vm._s(category.name) +
                                        "\n                            "
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ],
                          1
                        ),
                      ]),
                ]
              )
            }),
            0
          ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeService.vue?vue&type=template&id=f5465340&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeService.vue?vue&type=template&id=f5465340& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "service-system" }, [
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-md-4" }, [
            _c("div", { staticClass: "service" }, [
              _c("div", { staticClass: "service-icon" }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/core/7.png",
                    alt: "services",
                    height: "50",
                    width: "50",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "service-content" }, [
                _c("b", [_vm._v("Big Saving")]),
                _vm._v(" "),
                _c("span", [_vm._v("At Lowest Price")]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-md-4" }, [
            _c("div", { staticClass: "service" }, [
              _c("div", { staticClass: "service-icon" }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/core/6.png",
                    alt: "services",
                    height: "50",
                    width: "50",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "service-content" }, [
                _c("b", [_vm._v("24 Hour Support")]),
                _vm._v(" "),
                _c("span", [_vm._v("In Save Hand")]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-md-4" }, [
            _c("div", { staticClass: "service" }, [
              _c("div", { staticClass: "service-icon" }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/core/5.png",
                    alt: "services",
                    height: "50",
                    width: "50",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "service-content" }, [
                _c("b", [_vm._v("Flexible Delivery")]),
                _vm._v(" "),
                _c("span", [_vm._v("on order over $40")]),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeTestimonial.vue?vue&type=template&id=0c79a46c&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/homes/HomeTestimonial.vue?vue&type=template&id=0c79a46c& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "testimonials " }, [
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "row " }, [
          _c("div", { staticClass: "col-md-12 " }, [
            _c("h2", { staticClass: "sectitle " }, [
              _vm._v("What our clients are saying"),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row " }, [
          _c("div", { staticClass: "col-md-12 " }, [
            _c("div", { staticClass: "slider-container " }, [
              _c("div", { staticClass: "slider " }, [
                _c("div", { staticClass: "slide-box " }, [
                  _c("p", { staticClass: "comment " }, [
                    _vm._v(
                      "\n                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                            "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("img", {
                    attrs: {
                      src: "/frontend//images.unsplash.com/photo-1595152452543-e5fc28ebc2b8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=80 ",
                    },
                  }),
                  _vm._v(" "),
                  _c("h3", { staticClass: "name " }, [
                    _vm._v("Albert Sinelly"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "slide-box " }, [
                  _c("p", { staticClass: "comment " }, [
                    _vm._v(
                      "\n                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                            "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("img", {
                    attrs: {
                      src: "/frontend//images.unsplash.com/photo-1627541718143-1adc1b582e62?ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8bXVzbGltfGVufDB8MnwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
                    },
                  }),
                  _vm._v(" "),
                  _c("h3", { staticClass: "name " }, [_vm._v("Hirok Meryam")]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "slide-box " }, [
                  _c("p", { staticClass: "comment " }, [
                    _vm._v(
                      "\n                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                            "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("img", {
                    attrs: {
                      src: "/frontend//images.unsplash.com/photo-1610216705422-caa3fcb6d158?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzJ8fGZhY2V8ZW58MHwyfDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
                    },
                  }),
                  _vm._v(" "),
                  _c("h3", { staticClass: "name " }, [
                    _vm._v("Sebastian Sert"),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "control-slider btn-left ",
                  attrs: { href: "#! " },
                },
                [_c("i", { staticClass: "bi bi-chevron-left " })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "control-slider btn-right ",
                  attrs: { href: "#! " },
                },
                [_c("i", { staticClass: "bi bi-chevron-right " })]
              ),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Home.vue?vue&type=template&id=b3c5cf30&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Home.vue?vue&type=template&id=b3c5cf30& ***!
  \***********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "app-content-inner" }, [
    _c(
      "div",
      {
        staticClass: "home-landing-banner",
        staticStyle: { "background-color": "rgb(217 200 154)" },
      },
      [
        _c("img", {
          attrs: {
            src: _vm.banner ? "storage/uploads/media/" + _vm.banner : "",
            alt: "banner",
          },
        }),
      ]
    ),
    _vm._v(" "),
    _vm._m(0),
    _vm._v(" "),
    _vm._m(1),
    _vm._v(" "),
    _c("div", { staticClass: "item-categories-area" }, [
      _c(
        "div",
        { staticClass: "container-fluid" },
        [_vm._m(2), _vm._v(" "), _c("ProductCategories")],
        1
      ),
    ]),
    _vm._v(" "),
    _vm._m(3),
    _vm._v(" "),
    _vm._m(4),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "service-system" }, [
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-md-4" }, [
            _c("div", { staticClass: "service" }, [
              _c("div", { staticClass: "service-icon" }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/core/7.png",
                    alt: "services",
                    height: "50",
                    width: "50",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "service-content" }, [
                _c("b", [_vm._v("Big Saving")]),
                _vm._v(" "),
                _c("span", [_vm._v("At Lowest Price")]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-md-4" }, [
            _c("div", { staticClass: "service" }, [
              _c("div", { staticClass: "service-icon" }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/core/6.png",
                    alt: "services",
                    height: "50",
                    width: "50",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "service-content" }, [
                _c("b", [_vm._v("24 Hour Support")]),
                _vm._v(" "),
                _c("span", [_vm._v("In Save Hand")]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-md-4" }, [
            _c("div", { staticClass: "service" }, [
              _c("div", { staticClass: "service-icon" }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/core/5.png",
                    alt: "services",
                    height: "50",
                    width: "50",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "service-content" }, [
                _c("b", [_vm._v("Flexible Delivery")]),
                _vm._v(" "),
                _c("span", [_vm._v("on order over $40")]),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "discount-offer-refer" }, [
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "row justify-content-center" }, [
          _c("div", { staticClass: "col-6 col-md-6" }, [
            _c("a", { attrs: { href: "javascript:void(0)" } }, [
              _c("div", { staticClass: "discount-offer text-center" }, [
                _c("img", {
                  staticClass: "w-100",
                  attrs: { src: "/frontend/img/offer/4.jpg", alt: "offer" },
                }),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-6 col-md-6 text-center" }, [
            _c("a", { attrs: { href: "javascript:void(0)" } }, [
              _c("div", { staticClass: "discount-offer" }, [
                _c("img", {
                  attrs: { src: "/frontend/img/offer/6.jpg", alt: "offer" },
                }),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-12" }, [
        _c("h3", { staticClass: "sectitle" }, [
          _vm._v("Our Product Categories"),
        ]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "testimonials " }, [
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "row " }, [
          _c("div", { staticClass: "col-md-12 " }, [
            _c("h2", { staticClass: "sectitle " }, [
              _vm._v("What our clients are saying"),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row " }, [
          _c("div", { staticClass: "col-md-12 " }, [
            _c("div", { staticClass: "slider-container " }, [
              _c("div", { staticClass: "slider " }, [
                _c("div", { staticClass: "slide-box " }, [
                  _c("p", { staticClass: "comment " }, [
                    _vm._v(
                      "\n                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("img", {
                    attrs: {
                      src: "/frontend//images.unsplash.com/photo-1595152452543-e5fc28ebc2b8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=80 ",
                    },
                  }),
                  _vm._v(" "),
                  _c("h3", { staticClass: "name " }, [
                    _vm._v("Albert Sinelly"),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "slide-box " }, [
                  _c("p", { staticClass: "comment " }, [
                    _vm._v(
                      "\n                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("img", {
                    attrs: {
                      src: "/frontend//images.unsplash.com/photo-1627541718143-1adc1b582e62?ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8bXVzbGltfGVufDB8MnwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
                    },
                  }),
                  _vm._v(" "),
                  _c("h3", { staticClass: "name " }, [_vm._v("Hirok Meryam")]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "slide-box " }, [
                  _c("p", { staticClass: "comment " }, [
                    _vm._v(
                      "\n                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n                                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("img", {
                    attrs: {
                      src: "/frontend//images.unsplash.com/photo-1610216705422-caa3fcb6d158?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzJ8fGZhY2V8ZW58MHwyfDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
                    },
                  }),
                  _vm._v(" "),
                  _c("h3", { staticClass: "name " }, [
                    _vm._v("Sebastian Sert"),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "control-slider btn-left ",
                  attrs: { href: "#! " },
                },
                [_c("i", { staticClass: "bi bi-chevron-left " })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "control-slider btn-right ",
                  attrs: { href: "#! " },
                },
                [_c("i", { staticClass: "bi bi-chevron-right " })]
              ),
            ]),
          ]),
        ]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("footer", { attrs: { id: "footer " } }, [
      _c("div", { staticClass: "footer-top " }, [
        _c("div", { staticClass: "row " }, [
          _c("div", { staticClass: "col-12 col-md-6 " }, [
            _c("div", { staticClass: "footer-widget " }, [
              _c("div", { staticClass: "footer-logo " }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/logo/logo.png ",
                    alt: "logo ",
                    width: "200 ",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("p", { staticClass: "mb-0 " }, [
                _vm._v(
                  "\n                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, cupiditate a quisquam vel minus officiis corrupti voluptatum aliquid laborum tempora fuga placeat voluptas, quidem veniam repellendus soluta optio quia eaque!\n                        "
                ),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-6 col-md-3 " }, [
            _c("div", { staticClass: "footer-widget " }, [
              _c("div", { staticClass: "footer-widget-title s-font-600" }, [
                _vm._v("Customer Service"),
              ]),
              _vm._v(" "),
              _c("ul", { staticClass: "footer-menu " }, [
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Contact Us"),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Faq"),
                  ]),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-6 col-md-3 " }, [
            _c("div", { staticClass: "footer-widget " }, [
              _c("div", { staticClass: "footer-widget-title s-font-600" }, [
                _vm._v("About"),
              ]),
              _vm._v(" "),
              _c("ul", { staticClass: "footer-menu " }, [
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Privacy Policy"),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c("a", { attrs: { href: "javascript:void() " } }, [
                    _vm._v("Terms of Use"),
                  ]),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "footer-bottom " }, [
        _c("div", { staticClass: "contact-section " }, [
          _c("div", { staticClass: "phone-or-email s-font-500" }, [
            _c("span", [
              _c("img", {
                attrs: {
                  src: "/frontend/img/cart/phone.png ",
                  alt: "phone ",
                  width: "20 ",
                },
              }),
            ]),
            _vm._v(" "),
            _c("span", [
              _vm._v(
                "\n                            198789\n                        "
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "email " }, [
              _vm._v("\n                        or email "),
              _c("strong", [_vm._v("support@sombob.com")]),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "sociaol-section " }, [
          _c("ul", { staticClass: "social-icons " }, [
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/facebook.png ",
                    alt: "facebook ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/twitter.png ",
                    alt: "twitter ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/youtube.png ",
                    alt: "youtube ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("li", [
              _c("a", { attrs: { href: "javascript:void(0) " } }, [
                _c("img", {
                  attrs: {
                    src: "/frontend/img/social/instagram.png ",
                    alt: "instagram ",
                    width: "20 ",
                  },
                }),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js":
/*!********************************************************************!*\
  !*** ./node_modules/vue-loader/lib/runtime/componentNormalizer.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ normalizeComponent)
/* harmony export */ });
/* globals __VUE_SSR_CONTEXT__ */

// IMPORTANT: Do NOT use ES2015 features in this file (except for modules).
// This module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle.

function normalizeComponent (
  scriptExports,
  render,
  staticRenderFns,
  functionalTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier, /* server only */
  shadowMode /* vue-cli only */
) {
  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (render) {
    options.render = render
    options.staticRenderFns = staticRenderFns
    options._compiled = true
  }

  // functional template
  if (functionalTemplate) {
    options.functional = true
  }

  // scopedId
  if (scopeId) {
    options._scopeId = 'data-v-' + scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = shadowMode
      ? function () {
        injectStyles.call(
          this,
          (options.functional ? this.parent : this).$root.$options.shadowRoot
        )
      }
      : injectStyles
  }

  if (hook) {
    if (options.functional) {
      // for template-only hot-reload because in that case the render fn doesn't
      // go through the normalizer
      options._injectStyles = hook
      // register for functional component in vue file
      var originalRender = options.render
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return originalRender(h, context)
      }
    } else {
      // inject component registration as beforeCreate hook
      var existing = options.beforeCreate
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    }
  }

  return {
    exports: scriptExports,
    options: options
  }
}


/***/ })

}]);