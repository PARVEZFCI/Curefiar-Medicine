<link rel="stylesheet" href="/backend/css/dashlite.css?ver=2.8.0">
<link id="skin-default" rel="stylesheet" href="/backend/css/theme.css?ver=2.8.0">
<link rel="stylesheet" href="/backend/css/tinymce.css?ver=2.8.0">
<!-- tags input css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css" integrity="sha512-xmGTNt20S0t62wHLmQec2DauG9T+owP9e6VU8GigI0anN7OXLip9i7IwEhelasml2osdxX71XcYm6BQunTQeQg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- toast -->
<link href="{{ asset('css/iziToast.css') }}" rel="stylesheet">