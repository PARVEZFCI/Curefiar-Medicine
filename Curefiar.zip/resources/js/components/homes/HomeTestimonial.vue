<template>
    <div class="testimonials ">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12 ">
                    <h2 class="sectitle ">What our clients are saying</h2>
                </div>
            </div>

            <div class="row ">
                <div class="col-md-12 ">
                    <div class="slider-container ">
                        <div class="slider ">
                            <div class="slide-box ">
                                <!-- Testi One -->
                                <p class="comment ">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                                <img src="/frontend//images.unsplash.com/photo-1595152452543-e5fc28ebc2b8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=80 " />
                                <h3 class="name ">Albert Sinelly</h3>
                            </div>
                            <div class="slide-box ">
                                <!-- Testi Two -->
                                <p class="comment ">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                                <img src="/frontend//images.unsplash.com/photo-1627541718143-1adc1b582e62?ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8bXVzbGltfGVufDB8MnwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 " />
                                <h3 class="name ">Hirok Meryam</h3>
                            </div>
                            <div class="slide-box ">
                                <!-- Testi Three -->
                                <p class="comment ">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                                <img src="/frontend//images.unsplash.com/photo-1610216705422-caa3fcb6d158?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzJ8fGZhY2V8ZW58MHwyfDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 " />
                                <h3 class="name ">Sebastian Sert</h3>
                            </div>
                        </div>

                        <a href="#! " class="control-slider btn-left ">
                            <i class="bi bi-chevron-left "></i>
                        </a>
                        <a href="#! " class="control-slider btn-right ">
                            <i class="bi bi-chevron-right "></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>