<template>
    <div class="service-system">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="service">
                        <div class="service-icon">
                            <img src="/frontend/img/core/7.png" alt="services" height="50" width="50">
                        </div>
                        <div class="service-content">
                            <b>Big Saving</b>
                            <span>At Lowest Price</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service">
                        <div class="service-icon">
                            <img src="/frontend/img/core/6.png" alt="services" height="50" width="50">
                        </div>
                        <div class="service-content">
                            <b>24 Hour Support</b>
                            <span>In Save Hand</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service">
                        <div class="service-icon">
                            <img src="/frontend/img/core/5.png" alt="services" height="50" width="50">
                        </div>
                        <div class="service-content">
                            <b>Flexible Delivery</b>
                            <span>on order over $40</span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>