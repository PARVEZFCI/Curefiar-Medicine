<template>
    <div class="discount-offer-refer">
        <div class="row justify-content-center">
            <div class="col-6 col-md-6">
                <a href="javascript:void(0)">
                    <div class="discount-offer text-center">
                        <img src="/frontend/img/offer/5.jpg" alt="offer">
                    </div>
                </a>
            </div>
            <div class="col-6 col-md-6 text-center">
                <a href="javascript:void(0)">
                    <div class="discount-offer">
                        <img src="/frontend/img/offer/6.jpg" alt="offer">
                    </div>
                </a>
            </div>
        </div>
    </div>
</template>