<template>
    <footer id="footer ">
        <div class="footer-top ">
            <div class="row ">
                <div class="col-12 col-md-6 ">
                    <div class="footer-widget ">
                        <div class="footer-logo ">
                            <img src="/frontend/img/logo/logo.png " alt="logo " width="200 ">
                        </div>
                        <p class="mb-0 ">
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, cupiditate a quisquam vel minus officiis corrupti voluptatum aliquid laborum tempora fuga placeat voluptas, quidem veniam repellendus soluta optio quia eaque!
                        </p>
                    </div>
                </div>
                <div class="col-6 col-md-3 ">
                    <div class="footer-widget ">
                        <div class="footer-widget-title s-font-600">Customer Service</div>
                        <ul class="footer-menu ">
                            <li>
                                <a href="javascript:void() ">Contact Us</a>
                            </li>
                            <li>
                                <a href="javascript:void() ">Faq</a>
                            </li>
                            <li>
                                <a href="javascript:void() ">Help</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-6 col-md-3 ">
                    <div class="footer-widget ">
                        <div class="footer-widget-title s-font-600">About</div>
                        <ul class="footer-menu ">
                            <li>
                                <a href="javascript:void() ">Privacy Policy</a>
                            </li>
                            <li>
                                <a href="javascript:void() ">Terms of Use</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom ">
            <div class="contact-section ">
                <div class="phone-or-email s-font-500">
                    <span>
                            <img src="/frontend/img/cart/phone.png " alt="phone " width="20 ">
                        </span>
                    <span>
                            198789
                        </span>
                    <div class="email ">
                        or email <strong>support@sombob.com</strong>
                    </div>
                </div>
            </div>
            <div class="sociaol-section ">
                <ul class="social-icons ">
                    <li>
                        <a href="javascript:void(0) ">
                            <img src="/frontend/img/social/facebook.png " alt="facebook " width="20 ">
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0) ">
                            <img src="/frontend/img/social/twitter.png " alt="twitter " width="20 ">
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0) ">
                            <img src="/frontend/img/social/youtube.png " alt="youtube " width="20 ">
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0) ">
                            <img src="/frontend/img/social/instagram.png " alt="instagram " width="20 ">
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
</template>