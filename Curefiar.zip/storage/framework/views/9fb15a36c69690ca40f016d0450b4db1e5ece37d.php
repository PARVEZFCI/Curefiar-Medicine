<div class="modal fade" id="addCategoryModal" aria-modal="true" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal" aria-label="Close"> <em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body modal-body-md">
                <h5 class="title">Add Category</h5>
                <form enctype="multipart/form-data" action="<?php echo e(url('admin/product-categories')); ?>" method="POST" class="pt-2">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-label" for="email-address-1">Category</label>
                        <div class="form-control-wrap">
                            <input type="text" name="name" class="form-control" placeholder="Product Category">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="thumb">Icon</label>
                        <div class="form-control-wrap">
                            <div class="custom-file">
                                <input type="file" multiple="" class="custom-file-input" id="customFile" name="cate_icon">
                                <label class="custom-file-label" for="thumb">Choose file</label>
                            </div>
                        </div>
                        
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="thumb">Image</label>
                        <div class="form-control-wrap">
                            <div class="custom-file">
                                <input type="file" multiple="" class="custom-file-input" id="customFile" name="image">
                                <label class="custom-file-label" for="thumb">Choose file</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="thumb">Banner</label>
                        <div class="form-control-wrap">
                            <div class="custom-file">
                                <input type="file" multiple="" class="custom-file-input" id="customFile" name="cate_banner">
                                <label class="custom-file-label" for="thumb">Choose file</label>
                            </div>
                        </div>
                    </div>
                    <!-- Banner show -->
                    
                    <div class="form-group">
                        <button type="submit" class="btn theme-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH /opt/lampp/htdocs/Biz_it/Curefiar-Medicine/resources/views/partials/modals/add-category-modal.blade.php ENDPATH**/ ?>