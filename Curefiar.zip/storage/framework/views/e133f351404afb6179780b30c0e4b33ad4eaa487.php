<?php $__env->startSection('main_content'); ?>
<!-- Register Section -->
<section class="contact-section pad-80">
	<div class="container">
		<div class="row">
			<div class="col-md-5 m-auto">
				<h5 class="font-w-700 mb-4 text-center">Login With User Credentials</h5>
				<form action="<?php echo e(route('login.customer')); ?>" method="post" class="register-form box-shadow-1 br-5 p-4">
					<?php echo csrf_field(); ?>
					<div class="row p-4">
						<div class="col-md-12 col-xs-12">
							<div class="form-group">
								<input type="email" name="email" required class="form-control" placeholder="Enter Email *">
							</div>
						</div>
						<div class="col-md-12 col-xs-12">
							<div class="form-group">
								<input type="password" name="password" required class="form-control" placeholder="Enter Password *">
							</div>
						</div>
						<div class="col-sm-12 col-xs-12 mt-3">
							<div class="form-group mb-0">
								<button type="submit" class="btn bg-color-alpa custom-btn br-3 w-100">Login</button>
							</div>
						</div>

						<div class="col-md-12 col-xs-12 text-center pt-4">
							<span class="psw">New User? <a href="/customer-registration" style="color: #174f4f; text-decoration: underline;">Registration?</a></span>
						</div>

					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<!-- End Register Section-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Biz_it/Curefiar-Medicine/resources/views/frontend/auth/login.blade.php ENDPATH**/ ?>