<?php $__env->startSection('main_content'); ?>

<!-- Begin Single Product Details Area -->
			<section class="single-product-area pad-40">
				<div class="container">
					<div class="row">
						<div class="col-md-10 m-auto">
							<div class="row">
								<div class="col-md-4">
									<div class="single-product-left-side">
										<div class="single-product-image text-center">
											<img style="height: 200px;
											width: 259px;" src="<?php echo e($productsingle->thumbnail_image ? '/storage/uploads/product/' . $productsingle->thumbnail_image : '/image.svg'); ?>" alt="item">
										</div>
									</div>
								</div>
								<div class="col-md-8">
									<div class="single-product-right-side">
										<div class="single-product-desc-box">
											<div class="single-product-name">
												<h2 class="txt-clr-1 mb-3"><?php echo e($productsingle->name); ?></h2>
											</div>
											<p class="price-box">
												<?php if($productsingle->discount_price): ?>
												<span class="price-new">৳ <?php echo e($productsingle->discount_price); ?></span>
												<span class="price-old">৳ <?php echo e($productsingle->price); ?></span>
												<?php else: ?> 
												<span class="price-new">৳ <?php echo e($productsingle->price); ?></span>
												<?php endif; ?>
										  	</p>
											<p class="single-product-details">
										    <?php echo $productsingle->description; ?>	
											</p>
											<div class="d-flex align-items-center mt-4">
												
										    	<button onclick="forAddToCart(<?php echo e($productsingle->id); ?>,0)" class="custom-btn bg-color-alpa font-14
										    	font-w-700 cart-bag">Add To Cart</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- End Single Product Details Area -->
      <section class="related-product">
        <div class="container">

			<div class="row">
				<div class="col-md-12">
					<div class="head-title font-ct">
						<h2 class="modtitle">Related Product</h2>
						
					</div>
				</div>
			</div>
			
          <div class="row">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-md-3 col-md-3half">
                <div class="item">
                    <div class="product-item-container h-full w-full ct-item-box box-shadow-1">
                        <a href="<?php echo e(route('product.single',$product->slug)); ?>" class="img-box block relative">
                            <img  src="<?php echo e($product->thumbnail_image ? '/storage/uploads/product/' . $product->thumbnail_image : '/image.svg'); ?>">
                        </a>
                        <div class="product-desc-block">
                            <a href="<?php echo e(route('product.single',$product->slug)); ?>"><?php echo e($product->name); ?></a>
                            <p class="price-box">
                                <?php if($product->discount_price): ?> 
                                  <span class="price-new">৳ <?php echo e($product->discount_price); ?></span>
                                  <span class="price-old">৳ <?php echo e($product->price); ?></span>
                                  <?php else: ?> 
                                  <span class="price-new">৳ <?php echo e($product->price); ?></span>
                                  <?php endif; ?>
                              </p>
                            <div class="sku-quantity-section">
                                <input type="number" name="" min="1" value="1">
                                <button class="custom-btn bg-color-alpa font-14
                                font-w-700">
                                <span class="flaticon-shopping-bag"></span>
                                    Add To Cart</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Biz_it/Curefiar-Medicine/resources/views/frontend/singleproduct.blade.php ENDPATH**/ ?>